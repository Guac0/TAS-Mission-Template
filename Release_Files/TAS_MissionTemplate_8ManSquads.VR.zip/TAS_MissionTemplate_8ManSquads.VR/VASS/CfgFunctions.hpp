class TER
{
	class VASS
	{
		file = "VASS\fnc";
		class shop {
			preInit = 1;
		};
		class getItemValues {};
		class VASShandler {};
		class addShopCargo {};
		class addShop {};
		class resetTimer {};
		class getCurrency {};
		class setCurrency {};
	};
};
